
In order to test the web part of this application run node server (within the app directory)
as follows:
$node server.js

Then navigate your browser to:
http://localhost:8070/webapp/helloModule.html

