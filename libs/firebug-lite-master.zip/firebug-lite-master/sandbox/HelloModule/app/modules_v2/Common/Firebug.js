/* See license.txt for terms of usage */

define("Firebug",
[
    "exports", // comment this line and it will throw "Firebug is undefined" error
    "Firebug/CSS",
    "Firebug/DOM"
],
function(exports, Firebug){
// ********************************************************************************************* //

return Firebug;

// ********************************************************************************************* //
});
