﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CefSharp.Wpf.Example")]
[assembly: AssemblyCompany("Anthony Taranto")]
[assembly: AssemblyProduct("CefSharp")]
[assembly: AssemblyCopyright("Copyright © Anthony Taranto 2013")]

[assembly: AssemblyVersion("1.25.0.*")]
[assembly: ComVisible(false)]
