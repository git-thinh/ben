﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CefSharp.Test")]
[assembly: AssemblyCompany("Anthony Taranto")]
[assembly: AssemblyProduct("CefSharp")]
[assembly: AssemblyCopyright("Copyright © 2013")]

[assembly: AssemblyVersion("1.25.0.*")]
[assembly: ComVisible(false)]
